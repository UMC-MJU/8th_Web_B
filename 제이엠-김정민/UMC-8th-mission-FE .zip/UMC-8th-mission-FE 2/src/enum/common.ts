export enum PAGINATION_ORDER {
  "asc" = "asc",
  "desc" = "desc",
  LATEST = "LATEST",
}
