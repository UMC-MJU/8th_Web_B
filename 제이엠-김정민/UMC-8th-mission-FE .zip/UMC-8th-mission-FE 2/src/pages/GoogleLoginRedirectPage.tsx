import { useEffect } from "react";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { LOCAL_STORAGE_KEY } from "../constants/key";

const GoogleLoginRedirectPage = () => {
    const {setItem:setAccessToken} = useLocalStorage(LOCAL_STORAGE_KEY.accessToken)
    const {setItem:setRefreshToken} = useLocalStorage(LOCAL_STORAGE_KEY.refreshToekn)

    useEffect( () => {
        const urlParams = new URLSearchParams(window.location.search);
        const accessToken= urlParams.get(LOCAL_STORAGE_KEY.accessToken);
        const refreshToken = urlParams.get(LOCAL_STORAGE_KEY.refreshToekn);

        if(accessToken){ 
            setAccessToken(accessToken);
            setRefreshToken(refreshToken);
            window.location.href = "/me";
        }

    },[setAccessToken, setRefreshToken]);


    return <div>Google LoginPage입니다</div>;
};

export default GoogleLoginRedirectPage;
